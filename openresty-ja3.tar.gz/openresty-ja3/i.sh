#!/bin/bash

./configure --prefix=/usr/local/openresty \
            --with-luajit \
            --without-http_redis2_module \
            --with-http_iconv_module \
            --with-openssl=/usr/local/openssl

make && make install
